create definer = test@`%` trigger horse_in_race_repeat
  before INSERT
  on race_info
  for each row
BEGIN
	DECLARE HORSE_RACE_DATE DATE;
	DECLARE TOTAL_HORSE INTEGER;

  	SET HORSE_RACE_DATE = (SELECT race_date
									from race
									where id = NEW.race_id);
									
	SET TOTAL_HORSE = (SELECT COUNT(*)
								  FROM race r
								  JOIN RACE_INFO ri
								   ON r.id = ri.race_id
								  WHERE ri.HORSE_ID = NEW.horse_id and HORSE_RACE_DATE = r.race_date);

  	IF (TOTAL_HORSE > 0) THEN 
		SIGNAL SQLSTATE '23000' SET MESSAGE_TEXT = 'Error: can not added horse. It has already race in that date';	
  	END IF;
END;

